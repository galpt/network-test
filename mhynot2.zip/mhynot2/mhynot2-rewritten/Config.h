#pragma once

// TODO: this should be configurable at runtime, maybe from an ini or something

namespace Config {
	constexpr bool EmulatorMode = true;
}